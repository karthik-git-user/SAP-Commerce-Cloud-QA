/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Oct 8, 2020, 3:15:05 PM                     ---
 * ----------------------------------------------------------------
 */
package novalnet.novalnetcheckoutaddon.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast"})
public class GeneratedNovalnetcheckoutaddonConstants
{
	public static final String EXTENSIONNAME = "novalnetcheckoutaddon";
	
	protected GeneratedNovalnetcheckoutaddonConstants()
	{
		// private constructor
	}
	
	
}
